'use strict';

/**
 * @ngdoc overview
 * @name celebrityCruisesApp
 * @description
 * # celebrityCruisesApp
 *
 * Main module of the application.
 */
angular
  .module('celebrityCruisesApp', [
    'ngAnimate',
    'ngTouch',
    'ui.bootstrap'
  ]);
